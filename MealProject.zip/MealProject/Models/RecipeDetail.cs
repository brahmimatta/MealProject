﻿namespace MealProject.Models
{
    public class RecipeDetail
    {
        public string strMeal { get; set; }
        public string strMealThumb { get; set; }
        public string strInstructions { get; set; }
    }
}
