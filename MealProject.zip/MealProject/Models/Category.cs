﻿namespace MealProject.Models
{
    public class Category
    {
        public string strCategory { get; set; }
    }
}
