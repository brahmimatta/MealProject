﻿namespace MealProject.Models
{
    public class Recipe
    {
        public string idMeal { get; set; }
        public string strMeal { get; set; }
        public string strMealThumb { get; set; }
    }
}
